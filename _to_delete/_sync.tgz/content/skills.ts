import { projects } from "@/content/projects";

/**
 * Everything Dev works with, merged from all four résumés.
 *
 * `evidence` links a skill to the projects that actually used it, resolved from
 * each project's own stack list. A skills page that can point at where a thing
 * was used is worth more than one that just lists words.
 */

export interface Skill {
  name: string;
  /** Other spellings used in project stacks, so evidence resolves. */
  aliases?: string[];
  /** Set when the skill predates the projects on this site or has no stack entry. */
  note?: string;
}

export interface SkillGroup {
  id: string;
  label: string;
  note: string;
  items: Skill[];
}

export const skillGroups: SkillGroup[] = [
  {
    id: "frontend",
    label: "Frontend & Mobile",
    note: "Where most of the delivery happens.",
    items: [
      { name: "Next.js" },
      { name: "React", aliases: ["React.js"] },
      { name: "React Native" },
      { name: "TypeScript" },
      { name: "JavaScript (ES6+)" },
      { name: "Redux" },
      { name: "Tailwind CSS" },
      { name: "Responsive & cross-platform UI" },
      { name: "Android (Java, Kotlin)", aliases: ["Android", "Android (Kotlin)"] },
      { name: "Electron.js", aliases: ["Electron"] },
      { name: "Canvas" },
      { name: "Simulation engines" },
    ],
  },
  {
    id: "backend",
    label: "Backend",
    note: "Modular services, not monoliths.",
    items: [
      { name: "Node.js" },
      { name: "Express.js", aliases: ["Express"] },
      { name: "REST API design" },
      { name: "Microservices" },
      { name: "WebSocket" },
      { name: "Apache Kafka", aliases: ["Kafka"] },
      { name: "Swagger / OpenAPI" },
      { name: "SSO / OAuth 2.0", aliases: ["SSO"] },
      { name: "Google Sign-In", aliases: ["Google OAuth"] },
      { name: "Meta Login", aliases: ["Facebook Login"] },
      { name: "Sign in with Apple", aliases: ["Apple Sign-In"] },
    ],
  },
  {
    id: "data",
    label: "Databases & Caching",
    note: "Schema design, and the migrations between them.",
    items: [
      { name: "MongoDB" },
      { name: "PostgreSQL" },
      { name: "Redis" },
      { name: "Firebase" },
      { name: "Schema design" },
      { name: "Query optimisation & scaling" },
    ],
  },
  {
    id: "aws",
    label: "AWS",
    note: "Grouped by what they do: compute, storage, data, edge, messaging, operations.",
    items: [
      { name: "AWS", aliases: ["AWS (EC2, S3, RDS, IAM, CloudWatch, Lambda)"] },

      { name: "Amazon EC2", aliases: ["EC2"], note: "Compute — the instances application services run on." },
      { name: "AWS Elastic Beanstalk", aliases: ["Elastic Beanstalk"], note: "Managed application environments." },
      { name: "Amazon ECS", aliases: ["ECS"], note: "Container orchestration for the services." },
      { name: "AWS Lambda", aliases: ["Lambda"], note: "Event-driven functions off the request path." },
      { name: "Amazon EC2 Auto Scaling", aliases: ["Auto Scaling", "Autoscaling"], note: "Capacity that follows load." },

      { name: "Amazon S3", aliases: ["S3"], note: "Object storage — assets, artefacts, backups." },
      { name: "Amazon EBS", aliases: ["EBS", "Elastic Block Store"], note: "Block storage attached to instances." },

      { name: "Amazon RDS", aliases: ["RDS"], note: "Managed relational databases." },
      { name: "Amazon DynamoDB", aliases: ["DynamoDB"], note: "Managed key-value store." },

      { name: "Amazon Route 53", aliases: ["Route 53", "Route53"], note: "DNS and record management." },
      { name: "Elastic Load Balancing", aliases: ["ELB"], note: "Traffic distribution across instances." },
      { name: "Amazon CloudFront", aliases: ["CloudFront"], note: "CDN in front of the application." },

      { name: "Amazon SNS", aliases: ["SNS"], note: "Pub/sub notifications between services." },
      { name: "Amazon SQS", aliases: ["SQS"], note: "Queues that decouple slow work from requests." },

      { name: "AWS IAM", aliases: ["IAM"], note: "Roles and policies scoping what each service can touch." },
      { name: "Amazon CloudWatch", aliases: ["CloudWatch"] },
    ],
  },
  {
    id: "azure",
    label: "Azure",
    note: "The second cloud — where the observability platform lives.",
    items: [
      { name: "Azure", aliases: ["Azure (VMs, App Services, DevOps, Repos)"] },
      { name: "Azure App Service" },
      { name: "Azure Blob Storage", aliases: ["Blob Storage", "Storage containers"] },
      { name: "Azure Cosmos DB", aliases: ["Cosmos DB", "Cosmos"] },
      { name: "Azure AI Foundry" },
      { name: "Microsoft Entra ID", aliases: ["Entra ID", "Azure AD"] },
      { name: "Microsoft Entra PIM", aliases: ["PIM", "Privileged Identity Management"] },
      { name: "Azure DevOps" },
      { name: "Azure Repos" },
    ],
  },
  {
    id: "containers",
    label: "Containers & Monorepo",
    note: "The half of the job most full-stack engineers skip.",
    items: [
      { name: "Docker" },
      { name: "Docker Compose" },
      { name: "Nx Monorepo", aliases: ["Nx", "NX Monorepo"] },
    ],
  },
  {
    id: "iac",
    label: "Infrastructure as Code",
    note: "Environments defined in a repo, not in a console.",
    items: [
      { name: "Terraform" },
      { name: "CloudFormation" },
      { name: "Multi-environment deployments" },
      { name: "Blue-green deployment" },
    ],
  },
  {
    id: "cicd",
    label: "CI/CD & Monitoring",
    note: "Ship often, roll back fast, know when it breaks.",
    items: [
      { name: "CI/CD pipelines", aliases: ["CI/CD"] },
      { name: "GitHub Actions" },
      { name: "GitLab CI/CD" },
      { name: "Datadog" },
      { name: "ELK Stack" },
    ],
  },
  {
    id: "testing",
    label: "Testing & QA",
    note: "Coverage that catches regressions before release.",
    items: [
      { name: "Jest" },
      { name: "Cypress" },
      { name: "Selenium" },
      { name: "Unit testing" },
      { name: "Integration testing" },
      { name: "Smoke testing" },
    ],
  },
  {
    id: "ai",
    label: "AI & Integrations",
    note: "Third-party surfaces, wired end to end.",
    items: [
      { name: "GPT-5.4" },
      { name: "Okta" },
      { name: "Razorpay" },
      { name: "Google Maps" },
      { name: "Lokalise" },
      { name: "Meta Business APIs (WhatsApp, Facebook, Instagram)" },
    ],
  },
  {
    id: "tools",
    label: "Tooling & Practice",
    note: "How the work gets organised.",
    items: [
      { name: "Git" },
      { name: "GitHub" },
      { name: "GitLab" },
      { name: "Bitbucket" },
      { name: "JIRA" },
      { name: "Agile / Scrum" },
      { name: "ESLint" },
    ],
  },
];

/* ------------------------------------------------------------- evidence map */

const normalise = (value: string) => value.trim().toLowerCase();

/** Projects whose stack lists this skill, newest engagement first. */
export function evidenceFor(skill: Skill): string[] {
  const names = [skill.name, ...(skill.aliases ?? [])].map(normalise);
  return projects
    .filter((project) => project.stack.some((tech) => names.includes(normalise(tech))))
    .map((project) => project.slug);
}

/** Flat list for the hero marquee. Order is deliberate — most identifying first. */
export const marqueeSkills = [
  "Next.js", "TypeScript", "Node.js", "React Native", "MongoDB", "PostgreSQL",
  "Docker", "Terraform", "AWS", "Azure", "Kafka", "Redis", "GitHub Actions",
  "Nx", "Datadog", "Cypress",
];
